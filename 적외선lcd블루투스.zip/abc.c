/* vi: set sw=4 ts=4 expandtab: */
#include <misc.h>
#include <stm32f10x.h>
#include <stm32f10x_exti.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_usart.h>
#include <stm32f10x_adc.h>
#include <lcd.h>
#include <Touch.h>
#include <stdio.h>
#include <stdlib.h>
#include "config.h"
#include "interrupt.h"

int keypadMenu(int prevState, const char* msg);




TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
uint16_t CCR1_Val[2] = {1500, 100};
uint16_t CCR2_Val[2] = {1500, 100};
uint16_t CCR3_Val[2] = {1500, 100};
uint16_t CCR4_Val[2] = {1500, 100};
uint16_t PrescalerValue = 0;

void send_phone(char buf[]) {
    char *s = buf;
    while (*s) {
        while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
            ;
        USART_SendData(USART2, *s++);
    }
}

void openDoor(){ 
    TIM_OCInitTypeDef  TIM_OCInitStructure; 
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = CCR1_Val[0]; 
    TIM_OC4Init(TIM3, &TIM_OCInitStructure);

    TIM_OC2Init(TIM3, &TIM_OCInitStructure);
    
}


void closeDoor(){
    TIM_OCInitTypeDef  TIM_OCInitStructure; 
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = CCR1_Val[1]; 
    TIM_OC4Init(TIM3, &TIM_OCInitStructure);
    TIM_OC2Init(TIM3, &TIM_OCInitStructure);
}
void setBoards(){
    SystemInit();

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);     // interrupt
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);     // RCC GPIO E
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);     // RCC GPIO C
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);     // RCC GPIO D
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);     // ADC1 
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);       // DMA1

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO |
            RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    ADC_InitTypeDef ADC_InitStructure;
    ADC_DeInit(ADC1);
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 2;
    ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 1,
            ADC_SampleTime_55Cycles5);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 2,
            ADC_SampleTime_55Cycles5);
    ADC_Init(ADC1, &ADC_InitStructure);

    ADC_DMACmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);

    ADC_DMACmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);

    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1))
        ;
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1))
        ;
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);


    DMA_InitTypeDef DMA_InitStructure;
    DMA_DeInit(DMA1_Channel1);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) &ADC1->DR;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t) ADC_Value;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = 2;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    DMA_Cmd(DMA1_Channel1, ENABLE);


    GPIO_InitTypeDef LED;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);     // RCC GPIO D
    LED.GPIO_Mode = GPIO_Mode_Out_PP;
    LED.GPIO_Pin = GPIO_Pin_2;
    LED.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &LED);


    // 타이머 설정.
    NVIC_InitTypeDef NVIC_InitStructure; // for interreupt
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure; // timerbase...  
    /* TIM2 Clock Enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); 
    /* Enable TIM2 Global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure); 
    /* TIM2 Initialize */
    TIM_TimeBaseStructure.TIM_Period = 600;
    TIM_TimeBaseStructure.TIM_Prescaler = 60000;
    //계산방법 : 1/72mhz * 1200 * 60000
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure); 
    /* TIM2 Enale */
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE); // interrupt enable 


    /////////////////////////////////////////////
    // 이하 모다 소스

    /* TIM3 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    /* GPIOA and GPIOB clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
            RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);

    /*GPIOB Configuration: TIM3 channel1, 2, 3 and 4 */
    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_Init(GPIOC, &GPIO_InitStructure); 
    GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);	

    TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable); 
    TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable); 
    TIM_ARRPreloadConfig(TIM3, ENABLE); 
    TIM_Cmd(TIM3, ENABLE); 
    PrescalerValue = (uint16_t) (SystemCoreClock / 1000000) - 1;
    TIM_TimeBaseStructure.TIM_Period = 20000-1;
    TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);


    // bluetooth setting

    // pc 와의  usart 통신
    USART_InitTypeDef usart1_init_struct;
    GPIO_InitTypeDef gpioa_init_struct; 

    gpioa_init_struct.GPIO_Pin = GPIO_Pin_9;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpioa_init_struct);
    gpioa_init_struct.GPIO_Pin = GPIO_Pin_10;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpioa_init_struct);

    usart1_init_struct.USART_BaudRate = 57600;
    usart1_init_struct.USART_WordLength = USART_WordLength_8b;
    usart1_init_struct.USART_StopBits = USART_StopBits_1;
    usart1_init_struct.USART_Parity = USART_Parity_No;
    usart1_init_struct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    usart1_init_struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART1, &usart1_init_struct);
    USART_Cmd(USART1, ENABLE);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure); 

    USART_InitTypeDef usart2_init_struct; 

    // 보드 - 맛폰간의 블루투스 통신
    // tx, rx 설정
    gpioa_init_struct.GPIO_Pin = GPIO_Pin_2;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpioa_init_struct);

    gpioa_init_struct.GPIO_Pin = GPIO_Pin_3;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpioa_init_struct);

    usart2_init_struct.USART_BaudRate = 9600;
    usart2_init_struct.USART_WordLength = USART_WordLength_8b;
    usart2_init_struct.USART_StopBits = USART_StopBits_1;
    usart2_init_struct.USART_Parity = USART_Parity_No;
    usart2_init_struct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    usart2_init_struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART2, &usart2_init_struct);
    USART_Cmd(USART2, ENABLE);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

}



/*
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\7choterm.axf
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\flashclear.axf
   */
void delay(int i){
    int j;
    for(j=0; j<=i * 100000; j++);
}





/*
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\7choterm.axf
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\flashclear.axf
   */

int inBox(int x, int y, int sx, int sy, int ex, int ey){
    return sx <= x && x <= ex &&
        sy <= y && y <= ey;
}

int userMenu(int prevState){
    LCD_Clear(WHITE);
    screenState = OWN;

    LCD_DrawRectangle(5, 35, 65, 100);
    LCD_DrawRectangle(70, 35, 150, 100);
    LCD_DrawRectangle(155, 35, 235, 100);

    LCD_ShowString(5, 225, "close door", RED, WHITE);
    LCD_DrawRectangle(5, 225, 235, 280);
    // 물건이 있는지 표시!?
    // 닫기 버튼 누르면 문닫기.

    uint16_t pos_x,pos_y;
    uint16_t pix_x,pix_y;
    Touch_GetXY(&pos_x, &pos_y, 1); // 터치
    Convert_Pos(pos_x, pos_y, &pix_x, &pix_y); 
    if (inBox(pix_x, pix_y, 5, 225, 235, 280)){
        // 문닫기.
        // 모터 돌림.
        closeDoor();
    }

    screenState = prevState;
    return 0;
}

int guestMenu(int prevState){
    LCD_Clear(WHITE);
    screenState = GUEST;


    send_phone("delivery man open door");


    LCD_DrawRectangle(5, 35, 65, 100);
    LCD_DrawRectangle(70, 35, 150, 100);
    LCD_DrawRectangle(155, 35, 235, 100);

    LCD_ShowString(5, 225, "close door", RED, WHITE);
    LCD_DrawRectangle(5, 225, 235, 280);
    // 물건이 있는지 표시!?
    // 닫기 버튼 누르면 문닫기.

    uint16_t pos_x,pos_y;
    uint16_t pix_x,pix_y;
    Touch_GetXY(&pos_x, &pos_y, 1); // 터치
    Convert_Pos(pos_x, pos_y, &pix_x, &pix_y); 
    if (inBox(pix_x, pix_y, 5, 225, 235, 280)){
        // 문닫기.
        // 모터 돌림.
        closeDoor();
    }

    screenState = prevState;
    return 0;
}
int mainMenu() {
    char Magnetic[30];
    uint16_t pos_x,pos_y;
    uint16_t pix_x,pix_y;
    int ret;
    while(1){
        LCD_Clear(WHITE);
        char hint[30];
        sprintf(hint, "hint : %d", ownerPasswd);
        sprintf(Magnetic, "%d", MagneticValue);
        LCD_ShowString(100, 10, Magnetic, BLACK, WHITE);
        LCD_ShowString(0, 10, hint, RED, WHITE);
        LCD_ShowString(50, 150, "OWN", BLACK, WHITE);
        LCD_ShowString(120 + 50, 150, "GUEST", BLACK, WHITE);
        LCD_ShowString(50, 230, "CHANGE PASSWORD", RED, WHITE);

        LCD_DrawRectangle(5, 35, 65, 100);
        LCD_DrawRectangle(70, 35, 150, 100);
        LCD_DrawRectangle(155, 35, 235, 100);

        LCD_DrawRectangle(5, 120, 115, 220);

        LCD_DrawRectangle(120, 120, 235, 220);

        LCD_DrawRectangle(5, 225, 235, 280);
        LCD_ShowString(10, 300, "TEST", RED, WHITE);

        //////////////////////

        // ADC_Value[0] >= 0xF00 이면 물건 감지.

        /*LCD_ShowNum(100, 100, ADC_Value[0], 10, BLACK, WHITE);*/
        /*LCD_ShowNum(100, 150, ADC_Value[1], 4, BLACK, WHITE);*/
        ////////////////////////


        ////////////////////////
        Touch_GetXY(&pos_x, &pos_y, 1); // 터치
        Convert_Pos(pos_x, pos_y, &pix_x, &pix_y); 
        if (inBox(pix_x, pix_y, 5, 120, 115, 220)){   // 주인
            int retNum = keypadMenu(MAIN, "input password");
            if(retNum == ownerPasswd){
                // 문 열고,
                openDoor();
                userMenu(MAIN);
            }
            else{
                continue;
            } 
        } 
        if (inBox(pix_x, pix_y, 120, 120, 235, 220)) {   // 택배
            char buf[50];
            sprintf(buf, "delivery man's password = %d", guestPasswd);
            send_phone(buf);
            int retNum = keypadMenu(MAIN, "input pw to insert item");
            if(retNum == guestPasswd){
                // 서보모터를 돌린다.
                openDoor(); 
                // && 택배기사 메뉴 띄움.
                guestPasswd = rand() % 10000;
                guestMenu(MAIN);
            }
            else{
                continue; 
            }
        } 

        if (inBox(pix_x, pix_y, 5, 225, 235, 280)) {   // 사용자 비밀번호 변경.
            int retNum = keypadMenu(MAIN, "input original password");
            if(retNum == ownerPasswd){
                int changePass = keypadMenu(MAIN, "input new password");
                ownerPasswd = changePass;
            }
            // 비밀번호 변경 루틴.
        }
    }
    return 0;
}

int keypadMenu(int prevState, const char* msg){

    screenState = KEYPAD;
    uint16_t pos_x,pos_y;
    uint16_t pix_x,pix_y;
    int x, y;
    int h, w;
    int r, c;
    r = 4;
    c = 3;
    h = 235;
    w = 235;
    int marginX = 0;
    int dy = h / r;
    int dx = w / c;
    int nInput = 4;

    LCD_Clear(WHITE);

    // 가로 줄 그리기
    for(y=0; y<=r; y++){
        int startPointX = 0;
        int startPointY = dy * y;
        int endPointY = dy * y;
        int endPointX = w;

        LCD_DrawLine(startPointX, startPointY, endPointX, endPointY);
    }

    // 세로줄 그리기
    for(x = 0; x<=c; x++){
        int startPointX = dx * x;
        int startPointY = 0;
        int endPointX = dx * x;
        int endPointY = h;

        LCD_DrawLine(startPointX, startPointY, endPointX, endPointY);
    }

    // 숫자 넣기.
    int printNum = 1;
    int pointsX[12];
    int pointsY[12];
    for(y = 0; y<r; y++){
        for(x = 0; x<c; x++, printNum++){
            int leftTopX = dx * x;
            int leftTopY = dy * y;
            LCD_ShowNum(leftTopX + dx / 2, leftTopY + dy / 2, printNum, 2, BLACK, WHITE);
            pointsX[printNum-1] = leftTopX + dx / 2;
            pointsY[printNum-1] = leftTopY + dy / 2;
        }
    }

    LCD_ShowString(10, 300, (u8*)msg, RED, WHITE);
    int retValue = 0;
    for(int currentInput=0; currentInput < 4; ){
        Touch_GetXY(&pos_x, &pos_y, 1);
        for(volatile int i=0; i<100000; i++);
        Convert_Pos(pos_x, pos_y, &pix_x, &pix_y);

        for (int i = 0; i < 12; i++) {
            if (inBox(pix_x, pix_y, pointsX[i] - dx / 2, pointsY[i] - dy / 2,
                        pointsX[i] + dx / 2, pointsY[i] + dy / 2)) {
                int selectNum = i + 1;
                retValue *= 10;
                retValue += selectNum;

                currentInput++;
                break;
            }
        }
    } 
    screenState = prevState;
    LCD_Clear(WHITE);
    return retValue;
}

int main() { 
    setBoards(); 
    LCD_Init(); 
    Touch_Configuration();
    Touch_Adjust();
    LCD_Clear(WHITE);
    GPIOD->CRL = (GPIO_CRL_MODE2_0 | GPIO_CRL_MODE3_0 | GPIO_CRL_MODE4_0 | GPIO_CRL_MODE7_0); 
    mainMenu();
}
/*
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\7choterm.axf
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\flashclear.axf
   */

