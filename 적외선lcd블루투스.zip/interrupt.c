
#include <misc.h>
#include <stm32f10x.h>
#include <stm32f10x_exti.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_usart.h>
#include <stm32f10x_adc.h>
#include <lcd.h>

#include "config.h"

void TIM2_IRQHandler(void) {

  if(screenState == MAIN){
    uint32_t adc_value = ADC_Value[0];

    if(adc_value >= 0xF00){
      LCD_ShowString(100, 50, "you", BLACK, WHITE);
      LCD_ShowString(200, 50, "moo", WHITE, WHITE);
      // �뱀젙 醫뚰몴����異쒕젰.
    }
    else{
        LCD_ShowString(100, 50, "you", WHITE, WHITE);
      LCD_ShowString(200, 50, "moo", BLACK, WHITE);
      // �뱀젙 醫뚰몴��臾�異쒕젰.
    }
  }

  TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    //Clears the TIMx's interrupt pending bits.
} 

void USART1_IRQHandler(void) {
    unsigned char d;
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
        ;

    d = (unsigned char) USART_ReceiveData(USART1);
    USART_SendData(USART2, d);
    USART_ClearITPendingBit(USART1, USART_IT_RXNE); 
}

void USART2_IRQHandler(void) {
    unsigned char d;
    while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
        ;

    d = (unsigned char) USART_ReceiveData(USART2);
    USART_SendData(USART1, d);
    USART_ClearITPendingBit(USART2, USART_IT_RXNE); 
}
