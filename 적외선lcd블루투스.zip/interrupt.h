#ifndef __INT__H_
#define __INT__H_

void TIM2_IRQHandler(void);

void USART1_IRQHandler(void);
void USART2_IRQHandler(void);
#endif
