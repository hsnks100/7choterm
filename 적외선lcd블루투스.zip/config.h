#ifndef __CONFIG__H_
#define __CONFIG__H_
#include <misc.h>
extern int ownerPasswd;
extern int guestPasswd;

extern const int MAIN ;
extern const int OWN ;
extern const int GUEST ;
extern const int CHANGE ;
extern const int KEYPAD ;
extern int screenState;
extern uint32_t ADC_Value[4];
extern uint32_t MagneticValue;


#endif
