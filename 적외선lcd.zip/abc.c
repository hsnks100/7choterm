/* vi: set sw=4 ts=4 expandtab: */
#include <misc.h>
#include <stm32f10x.h>
#include <stm32f10x_exti.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_usart.h>
#include <stm32f10x_adc.h>
#include <lcd.h>
#include <Touch.h>
#include <stdio.h>
#include <stdlib.h>
#include "config.h"
#include "interrupt.h"

int keypadMenu(int prevState, const char* msg);


int button_pos[4][2];
int button[] = {0, 0, 0, 0};


void setBoards(){
    SystemInit();

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);	 // interrupt
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);     // RCC GPIO E
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);     // RCC GPIO C
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);     // RCC GPIO D
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);	 // ADC1 
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);       // DMA1

    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    ADC_InitTypeDef ADC_InitStructure;
    ADC_DeInit(ADC1);
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 2;
    ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 1,
            ADC_SampleTime_55Cycles5);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 2,
            ADC_SampleTime_55Cycles5);
    ADC_Init(ADC1, &ADC_InitStructure);

    ADC_DMACmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);



    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1))
        ;
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1))
        ;
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);


    DMA_InitTypeDef DMA_InitStructure;
    DMA_DeInit(DMA1_Channel1);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) &ADC1->DR;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t) ADC_Value;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = 2;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    DMA_Cmd(DMA1_Channel1, ENABLE);

    GPIO_InitTypeDef LED;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);     // RCC GPIO D
    LED.GPIO_Mode = GPIO_Mode_Out_PP;
    LED.GPIO_Pin = GPIO_Pin_2;
    LED.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &LED);


    // 타이머 설정.
    NVIC_InitTypeDef NVIC_InitStructure; // for interreupt
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure; // timerbase...  
    /* TIM2 Clock Enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); 
    /* Enable TIM2 Global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure); 
    /* TIM2 Initialize */
    TIM_TimeBaseStructure.TIM_Period = 600;
    TIM_TimeBaseStructure.TIM_Prescaler = 60000;
    //계산방법 : 1/72mhz * 1200 * 60000
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure); 
    /* TIM2 Enale */
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE); // interrupt enable 
}



/*
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\7choterm.axf
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\flashclear.axf
   */
void delay(int i){
    int j;
    for(j=0; j<=i * 100000; j++);
}





/*
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\7choterm.axf
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\flashclear.axf
   */

int inBox(int x, int y, int sx, int sy, int ex, int ey){
    return sx <= x && x <= ex &&
        sy <= y && y <= ey;
}

int userMenu(int prevState){
    
    screenState = OWN;

    LCD_DrawRectangle(5, 35, 65, 100);
    LCD_DrawRectangle(70, 35, 150, 100);
    LCD_DrawRectangle(155, 35, 235, 100);

    LCD_ShowString(5, 225, "close door", RED, WHITE);
    LCD_DrawRectangle(5, 225, 235, 280);
    // 물건이 있는지 표시!? 
    // 닫기 버튼 누르면 문닫기. 

    uint16_t pos_x,pos_y;
    uint16_t pix_x,pix_y;
    Touch_GetXY(&pos_x, &pos_y, 1); // 터치
    Convert_Pos(pos_x, pos_y, &pix_x, &pix_y); 
    if (inBox(pix_x, pix_y, 5, 225, 235, 280)){
        // 문닫기.
        // 모터 돌림.  
    }

    screenState = prevState;
    return 0;
}

int guestMenu(int prevState){
    screenState = GUEST;
    // 닫기 누르면 문닫기.

    // 문담았을 때 적외선 센서 읽어와서, 블루투스 통신.
    //


    screenState = prevState;
    return 0;
}
int mainMenu() {

    uint16_t pos_x,pos_y;
    uint16_t pix_x,pix_y;
    int ret;
    while(1){
        LCD_Clear(WHITE);
        char hint[30];
        sprintf(hint, "hint : %d", ownerPasswd);
        LCD_ShowString(0, 10, hint, RED, WHITE);
        LCD_ShowString(50, 150, "OWN", BLACK, WHITE);
        LCD_ShowString(120 + 50, 150, "GUEST", BLACK, WHITE);
        LCD_ShowString(110, 190, "CHANGE PASSWORD", RED, WHITE);

        LCD_DrawRectangle(5, 35, 65, 100);
        LCD_DrawRectangle(70, 35, 150, 100);
        LCD_DrawRectangle(155, 35, 235, 100);

        LCD_DrawRectangle(5, 120, 115, 220);

        LCD_DrawRectangle(120, 120, 235, 220);

        LCD_DrawRectangle(5, 225, 235, 280);
        LCD_ShowString(10, 300, "TEST", RED, WHITE);

        //////////////////////

        // ADC_Value[0] >= 0xF00 이면 물건 감지.

        /*LCD_ShowNum(100, 100, ADC_Value[0], 10, BLACK, WHITE);*/
        /*LCD_ShowNum(100, 150, ADC_Value[1], 4, BLACK, WHITE);*/
        ////////////////////////


        Touch_GetXY(&pos_x, &pos_y, 1); // 터치
        Convert_Pos(pos_x, pos_y, &pix_x, &pix_y); 
        if (inBox(pix_x, pix_y, 5, 120, 115, 220)){   // 주인
            int retNum = keypadMenu(MAIN, "input password");
            if(retNum == ownerPasswd){
                // 문 열고, 
                userMenu(MAIN);
            }
            else{
                continue;
            } 
        } 
        if (inBox(pix_x, pix_y, 120, 120, 235, 220)) {   // 택배
            int retNum = keypadMenu(MAIN, "input pw to insert item");
            if(retNum == guestPasswd){
                // 서보모터를 돌린다.

                // && 택배기사 메뉴 띄움.
                guestMenu(MAIN);
            }
            else{
                continue;

            }
        }

        if (inBox(pix_x, pix_y, 5, 225, 235, 280)) {   // 사용자 비밀번호 변경.
            int retNum = keypadMenu(MAIN, "input original password");
            if(retNum == ownerPasswd){
                int changePass = keypadMenu(MAIN, "input new password");
                ownerPasswd = changePass;
            }
            // 비밀번호 변경 루틴.
        }
    }
    return 0;
}

int keypadMenu(int prevState, const char* msg){

    screenState = KEYPAD;
    uint16_t pos_x,pos_y;
    uint16_t pix_x,pix_y;
    int x, y;
    int h, w;
    int r, c;
    r = 4;
    c = 3;
    h = 235;
    w = 235;
    int marginX = 0;
    int dy = h / r;
    int dx = w / c;
    int nInput = 4;
    LCD_Clear(WHITE);

    // 가로 줄 그리기
    for(y=0; y<=r; y++){
        int startPointX = 0;
        int startPointY = dy * y;
        int endPointY = dy * y;
        int endPointX = w;

        LCD_DrawLine(startPointX, startPointY, endPointX, endPointY);
    }

    // 세로줄 그리기
    for(x = 0; x<=c; x++){
        int startPointX = dx * x;
        int startPointY = 0;
        int endPointX = dx * x;
        int endPointY = h;

        LCD_DrawLine(startPointX, startPointY, endPointX, endPointY);
    }

    // 숫자 넣기.
    int printNum = 1;
    int pointsX[12];
    int pointsY[12];
    for(y = 0; y<r; y++){
        for(x = 0; x<c; x++, printNum++){
            int leftTopX = dx * x;
            int leftTopY = dy * y;
            LCD_ShowNum(leftTopX + dx / 2, leftTopY + dy / 2, printNum, 2, BLACK, WHITE);
            pointsX[printNum-1] = leftTopX + dx / 2;
            pointsY[printNum-1] = leftTopY + dy / 2;
        }
    }

    LCD_ShowString(10, 300, (u8*)msg, RED, WHITE);
    int retValue = 0;
    for(int currentInput=0; currentInput < 4; ){
        Touch_GetXY(&pos_x, &pos_y, 1);
        for(volatile int i=0; i<100000; i++);
        Convert_Pos(pos_x, pos_y, &pix_x, &pix_y);

        for (int i = 0; i < 12; i++) {
            if (inBox(pix_x, pix_y, pointsX[i] - dx / 2, pointsY[i] - dy / 2,
                        pointsX[i] + dx / 2, pointsY[i] + dy / 2)) {
                int selectNum = i + 1;
                retValue *= 10;
                retValue += selectNum;

                currentInput++;
                break;
            }
        }
    }


    screenState = prevState;
    LCD_Clear(WHITE);
    return retValue;
}

int main() { 
    setBoards();

    LCD_Init(); 
    Touch_Configuration();
    Touch_Adjust();
    LCD_Clear(WHITE);
    GPIOD->CRL = (GPIO_CRL_MODE2_0 | GPIO_CRL_MODE3_0 | GPIO_CRL_MODE4_0 | GPIO_CRL_MODE7_0); 
    mainMenu();
}
/*
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\7choterm.axf
   flash load C:\Users\USER\Desktop\team7\7choterm\Debug\flashclear.axf
   */



