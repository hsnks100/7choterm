
#include <misc.h>
#include <stm32f10x.h>
#include <stm32f10x_exti.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_usart.h>
#include <stm32f10x_adc.h>
#include <lcd.h>

#include "config.h"

void TIM2_IRQHandler(void) {

  if(screenState == MAIN){
    uint32_t adc_value = ADC_Value[0];

    if(adc_value >= 0xF00){
      LCD_ShowString(100, 100, "you", BLACK, WHITE); 
      // 특정 좌표에 유 출력.
    }
    else{
      LCD_ShowString(100, 100, "moo", BLACK, WHITE);
      // 특정 좌표에 무 출력.
    }
  }

  TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    //Clears the TIMx's interrupt pending bits.
}
