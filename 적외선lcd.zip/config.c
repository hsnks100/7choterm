#include "config.h"

 const int MAIN = 0;
 const int OWN = 1;
 const int GUEST = 2;
 const int CHANGE = 3;
 const int KEYPAD = 4;
int ownerPasswd = 4343;
int guestPasswd = 4343;
int screenState = MAIN;
uint32_t ADC_Value[4];
